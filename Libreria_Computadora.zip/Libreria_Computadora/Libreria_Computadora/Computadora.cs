﻿namespace Libreria_Computadora
{
    public class Computadora
    {
        private int capacidadDisco;
        private int memoriaRam;
        private string procesador;
        private List<string> programas;
        private string sistemaOperativo;

        private Computadora()
        {
            this.programas = new List<string>();
        }
        public Computadora(int capacidadDisco, int memoriaRam, string procesador, string sistemaOperativo)
            :this()
        {
            this.capacidadDisco = capacidadDisco;
            this.memoriaRam = memoriaRam;
            this.procesador = procesador;
            this.sistemaOperativo = sistemaOperativo;
        }

       

        public int CapacidadDisco { get => capacidadDisco; }
        public int MemoriaRam { get => memoriaRam; }
        public string Procesador { get => procesador; }
        public string SistemaOperativo { get => sistemaOperativo; }
        public List<string> Programas
        {
            get
            {
                return Programas;
            }
        }

        public static List<string> ListadoDeProcesadores()
        {
            List<string> listaDeProcesadores = new List<string>()
            {
                "Procesador1", "Procesador2","Procesador3","Procesador4","Procesador5"
            };
           return listaDeProcesadores;
        }

        public static List<Computadora> ListaDeComputadoras()
        {
            return new List<Computadora>();
        }








    }
}
