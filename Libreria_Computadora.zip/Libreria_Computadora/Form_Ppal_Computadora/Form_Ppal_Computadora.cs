
using Libreria_Computadora;

namespace Form_Ppal_Computadora
{
    public partial class Form_Ppal_Computadora : Form
    {
        public Form_Ppal_Computadora()
        {
            InitializeComponent();
        }









    }
}
