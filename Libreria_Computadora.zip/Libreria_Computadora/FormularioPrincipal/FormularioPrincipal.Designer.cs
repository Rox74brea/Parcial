﻿namespace FormularioPrincipal
{
    partial class FormularioPrincipal
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgv_InfoComputadora = new DataGridView();
            btn_Agregar = new Button();
            ((System.ComponentModel.ISupportInitialize)dgv_InfoComputadora).BeginInit();
            SuspendLayout();
            // 
            // dgv_InfoComputadora
            // 
            dgv_InfoComputadora.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgv_InfoComputadora.Location = new Point(34, 21);
            dgv_InfoComputadora.Name = "dgv_InfoComputadora";
            dgv_InfoComputadora.Size = new Size(725, 254);
            dgv_InfoComputadora.TabIndex = 0;
            // 
            // btn_Agregar
            // 
            btn_Agregar.Location = new Point(304, 331);
            btn_Agregar.Name = "btn_Agregar";
            btn_Agregar.Size = new Size(186, 23);
            btn_Agregar.TabIndex = 1;
            btn_Agregar.Text = "AGREGAR";
            btn_Agregar.UseVisualStyleBackColor = true;
            // 
            // FormularioPrincipal
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btn_Agregar);
            Controls.Add(dgv_InfoComputadora);
            Name = "FormularioPrincipal";
            Text = "Computadoras";
            Load += FormularioPrincipal_Load;
            ((System.ComponentModel.ISupportInitialize)dgv_InfoComputadora).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dgv_InfoComputadora;
        private Button btn_Agregar;
    }
}
