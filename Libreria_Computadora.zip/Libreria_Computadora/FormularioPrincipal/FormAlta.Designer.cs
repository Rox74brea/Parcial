﻿namespace FormularioPrincipal
{
    partial class FormAlta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            gpb_Hardware = new GroupBox();
            nud_Disco = new NumericUpDown();
            nud_Memoria = new NumericUpDown();
            txt_Procesador = new TextBox();
            lbl_Disco = new Label();
            lbl_MemoriaRam = new Label();
            lbl_Procesador = new Label();
            gpb_SistemaOperativo = new GroupBox();
            rd_MacOs = new RadioButton();
            rd_Linux = new RadioButton();
            rd_Windows = new RadioButton();
            gpb_Programas = new GroupBox();
            ckb_Avast = new CheckBox();
            ckb_Dropbox = new CheckBox();
            ckb_Winrar = new CheckBox();
            ckb_Adobe = new CheckBox();
            ckb_Office = new CheckBox();
            btn_Agregar = new Button();
            button2 = new Button();
            gpb_Hardware.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)nud_Disco).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nud_Memoria).BeginInit();
            gpb_SistemaOperativo.SuspendLayout();
            gpb_Programas.SuspendLayout();
            SuspendLayout();
            // 
            // gpb_Hardware
            // 
            gpb_Hardware.Controls.Add(nud_Disco);
            gpb_Hardware.Controls.Add(nud_Memoria);
            gpb_Hardware.Controls.Add(txt_Procesador);
            gpb_Hardware.Controls.Add(lbl_Disco);
            gpb_Hardware.Controls.Add(lbl_MemoriaRam);
            gpb_Hardware.Controls.Add(lbl_Procesador);
            gpb_Hardware.Location = new Point(12, 22);
            gpb_Hardware.Name = "gpb_Hardware";
            gpb_Hardware.Size = new Size(379, 311);
            gpb_Hardware.TabIndex = 0;
            gpb_Hardware.TabStop = false;
            gpb_Hardware.Text = "HardWare";
            // 
            // nud_Disco
            // 
            nud_Disco.Location = new Point(130, 185);
            nud_Disco.Name = "nud_Disco";
            nud_Disco.Size = new Size(145, 23);
            nud_Disco.TabIndex = 5;
            // 
            // nud_Memoria
            // 
            nud_Memoria.Location = new Point(130, 122);
            nud_Memoria.Name = "nud_Memoria";
            nud_Memoria.Size = new Size(145, 23);
            nud_Memoria.TabIndex = 4;
            // 
            // txt_Procesador
            // 
            txt_Procesador.Location = new Point(130, 57);
            txt_Procesador.Name = "txt_Procesador";
            txt_Procesador.Size = new Size(145, 23);
            txt_Procesador.TabIndex = 3;
            // 
            // lbl_Disco
            // 
            lbl_Disco.AutoSize = true;
            lbl_Disco.Location = new Point(6, 193);
            lbl_Disco.Name = "lbl_Disco";
            lbl_Disco.Size = new Size(36, 15);
            lbl_Disco.TabIndex = 2;
            lbl_Disco.Text = "Disco";
            // 
            // lbl_MemoriaRam
            // 
            lbl_MemoriaRam.AutoSize = true;
            lbl_MemoriaRam.Location = new Point(6, 122);
            lbl_MemoriaRam.Name = "lbl_MemoriaRam";
            lbl_MemoriaRam.Size = new Size(82, 15);
            lbl_MemoriaRam.TabIndex = 1;
            lbl_MemoriaRam.Text = "Memoria Ram";
            // 
            // lbl_Procesador
            // 
            lbl_Procesador.AutoSize = true;
            lbl_Procesador.Location = new Point(6, 60);
            lbl_Procesador.Name = "lbl_Procesador";
            lbl_Procesador.Size = new Size(66, 15);
            lbl_Procesador.TabIndex = 0;
            lbl_Procesador.Text = "Procesador";
            // 
            // gpb_SistemaOperativo
            // 
            gpb_SistemaOperativo.Controls.Add(rd_MacOs);
            gpb_SistemaOperativo.Controls.Add(rd_Linux);
            gpb_SistemaOperativo.Controls.Add(rd_Windows);
            gpb_SistemaOperativo.Location = new Point(477, 22);
            gpb_SistemaOperativo.Name = "gpb_SistemaOperativo";
            gpb_SistemaOperativo.Size = new Size(263, 137);
            gpb_SistemaOperativo.TabIndex = 1;
            gpb_SistemaOperativo.TabStop = false;
            gpb_SistemaOperativo.Text = "Sistema Operativo";
            // 
            // rd_MacOs
            // 
            rd_MacOs.AutoSize = true;
            rd_MacOs.Location = new Point(25, 101);
            rd_MacOs.Name = "rd_MacOs";
            rd_MacOs.Size = new Size(62, 19);
            rd_MacOs.TabIndex = 2;
            rd_MacOs.TabStop = true;
            rd_MacOs.Text = "MacOs";
            rd_MacOs.UseVisualStyleBackColor = true;
            // 
            // rd_Linux
            // 
            rd_Linux.AutoSize = true;
            rd_Linux.Location = new Point(25, 67);
            rd_Linux.Name = "rd_Linux";
            rd_Linux.Size = new Size(54, 19);
            rd_Linux.TabIndex = 1;
            rd_Linux.TabStop = true;
            rd_Linux.Text = "Linux";
            rd_Linux.UseVisualStyleBackColor = true;
            // 
            // rd_Windows
            // 
            rd_Windows.AutoSize = true;
            rd_Windows.Location = new Point(26, 34);
            rd_Windows.Name = "rd_Windows";
            rd_Windows.Size = new Size(74, 19);
            rd_Windows.TabIndex = 0;
            rd_Windows.TabStop = true;
            rd_Windows.Text = "Windows";
            rd_Windows.UseVisualStyleBackColor = true;
            // 
            // gpb_Programas
            // 
            gpb_Programas.Controls.Add(ckb_Avast);
            gpb_Programas.Controls.Add(ckb_Dropbox);
            gpb_Programas.Controls.Add(ckb_Winrar);
            gpb_Programas.Controls.Add(ckb_Adobe);
            gpb_Programas.Controls.Add(ckb_Office);
            gpb_Programas.Location = new Point(477, 178);
            gpb_Programas.Name = "gpb_Programas";
            gpb_Programas.Size = new Size(263, 155);
            gpb_Programas.TabIndex = 2;
            gpb_Programas.TabStop = false;
            gpb_Programas.Text = "Programas";
            // 
            // ckb_Avast
            // 
            ckb_Avast.AutoSize = true;
            ckb_Avast.Location = new Point(17, 122);
            ckb_Avast.Name = "ckb_Avast";
            ckb_Avast.Size = new Size(55, 19);
            ckb_Avast.TabIndex = 4;
            ckb_Avast.Text = "Avast";
            ckb_Avast.UseVisualStyleBackColor = true;
            // 
            // ckb_Dropbox
            // 
            ckb_Dropbox.AutoSize = true;
            ckb_Dropbox.Location = new Point(17, 97);
            ckb_Dropbox.Name = "ckb_Dropbox";
            ckb_Dropbox.Size = new Size(72, 19);
            ckb_Dropbox.TabIndex = 3;
            ckb_Dropbox.Text = "DropBox";
            ckb_Dropbox.UseVisualStyleBackColor = true;
            // 
            // ckb_Winrar
            // 
            ckb_Winrar.AutoSize = true;
            ckb_Winrar.Location = new Point(17, 72);
            ckb_Winrar.Name = "ckb_Winrar";
            ckb_Winrar.Size = new Size(61, 19);
            ckb_Winrar.TabIndex = 2;
            ckb_Winrar.Text = "Winrar";
            ckb_Winrar.UseVisualStyleBackColor = true;
            // 
            // ckb_Adobe
            // 
            ckb_Adobe.AutoSize = true;
            ckb_Adobe.Location = new Point(17, 47);
            ckb_Adobe.Name = "ckb_Adobe";
            ckb_Adobe.Size = new Size(61, 19);
            ckb_Adobe.TabIndex = 1;
            ckb_Adobe.Text = "Adobe";
            ckb_Adobe.UseVisualStyleBackColor = true;
            // 
            // ckb_Office
            // 
            ckb_Office.AutoSize = true;
            ckb_Office.Location = new Point(17, 22);
            ckb_Office.Name = "ckb_Office";
            ckb_Office.Size = new Size(58, 19);
            ckb_Office.TabIndex = 0;
            ckb_Office.Text = "Office";
            ckb_Office.UseVisualStyleBackColor = true;
            // 
            // btn_Agregar
            // 
            btn_Agregar.Location = new Point(477, 395);
            btn_Agregar.Name = "btn_Agregar";
            btn_Agregar.Size = new Size(122, 23);
            btn_Agregar.TabIndex = 3;
            btn_Agregar.Text = "AGREGAR";
            btn_Agregar.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            button2.Location = new Point(638, 395);
            button2.Name = "button2";
            button2.Size = new Size(97, 23);
            button2.TabIndex = 4;
            button2.Text = "CANCELAR";
            button2.UseVisualStyleBackColor = true;
            // 
            // FormAlta
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button2);
            Controls.Add(btn_Agregar);
            Controls.Add(gpb_Programas);
            Controls.Add(gpb_SistemaOperativo);
            Controls.Add(gpb_Hardware);
            Name = "FormAlta";
            Text = "FormAlta";
            Load += FormAlta_Load;
            gpb_Hardware.ResumeLayout(false);
            gpb_Hardware.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)nud_Disco).EndInit();
            ((System.ComponentModel.ISupportInitialize)nud_Memoria).EndInit();
            gpb_SistemaOperativo.ResumeLayout(false);
            gpb_SistemaOperativo.PerformLayout();
            gpb_Programas.ResumeLayout(false);
            gpb_Programas.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox gpb_Hardware;
        private GroupBox gpb_SistemaOperativo;
        private GroupBox gpb_Programas;
        private Button btn_Agregar;
        private Button button2;
        private NumericUpDown nud_Disco;
        private NumericUpDown nud_Memoria;
        private TextBox txt_Procesador;
        private Label lbl_Disco;
        private Label lbl_MemoriaRam;
        private Label lbl_Procesador;
        private RadioButton rd_MacOs;
        private RadioButton rd_Linux;
        private RadioButton rd_Windows;
        private CheckBox ckb_Avast;
        private CheckBox ckb_Dropbox;
        private CheckBox ckb_Winrar;
        private CheckBox ckb_Adobe;
        private CheckBox ckb_Office;
    }
}