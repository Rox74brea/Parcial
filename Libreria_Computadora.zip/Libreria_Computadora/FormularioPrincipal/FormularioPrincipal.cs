
using Libreria_Computadora;

namespace FormularioPrincipal
{
    public partial class FormularioPrincipal : Form
    {
        private List<Computadora> computadoras;
        public FormularioPrincipal()
        {
            InitializeComponent();
        }

        private void FormularioPrincipal_Load(object sender, EventArgs e)
        {
            this.computadoras = new List<Computadora>();
            this.computadoras = Computadora.ListaDeComputadoras();
            this.dgv_InfoComputadora.DataSource = this.computadoras;

        }
    }
}
